public class Nested_If {
    public void pattern1() {
        int n = 5;
        for (int row = 0; row < 2 * n; row++) {
            int total_column_in_row = row > n ? 2* n - row : row;
          for(int col=0; col< total_column_in_row; col++)
          {
              System.out.print("* ");
          }
            System.out.println();
        }
    }
    public static void main(String arg[])
    {
        Nested_If obj = new Nested_If();
        obj.pattern1();
    }
}
